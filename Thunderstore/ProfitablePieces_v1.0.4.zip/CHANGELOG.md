| `Version` | `Update Notes`                                                                                                                                      |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.0.4     | - Courtesy Update for Bog Witch. Just bumping the version and updating the last updated date. Nothing to see here.                                  |
| 1.0.3     | - Courtesy Update for Valheim 0.217.46. Just bumping the version and updating the last updated date. Nothing to see here.                           |
| 1.0.2     | - Updates for Valheim 0.217.22                                                                                                                      |
| 1.0.1     | - Fix a bug caused by me copying my configuration bind. Resulting in the Always Excluded Drop Resources setting to not even be created/take effect. |
| 1.0.0     | - Initial Release                                                                                                                                   |
